function hardik
	B=zeros(10,8);	
	for i =(8:8)
		for k=(1:1)
			cnt=0;
			sz=10^i;
			A=rand(sz,2);
			A.*2;
			for j =(1:sz)
				if(A(j,1)^2+A(j,2)^2<1)
					cnt=cnt+1;
				endif
			endfor
			B(k,i)=(cnt*4)/sz;
			clear A
		endfor
	endfor
	save data.mat B
endfunction
