function hardik
	for i = (2:4)
		A=zeros(10^i,2);
		printf("%d\n",i);
	endfor
endfunction