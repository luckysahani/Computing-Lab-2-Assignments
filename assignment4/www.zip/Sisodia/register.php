<html>
<body>
<h3>Registration Form</h3>

<form action="register_result.php" method="post">
Username*: <input type="text" name="username" required="required">
Password*: <input type="password" name="password" required="required">
<input type="submit">
</form>

</body>
</html>

