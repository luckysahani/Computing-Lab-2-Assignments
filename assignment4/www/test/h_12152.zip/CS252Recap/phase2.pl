#!/usr/bin/perl -w
#use ./phase2.pl <phase1.out <mysql password>
  $mysql_pwd=shift;
  # print $thing;
  system "mysql -u root -p$mysql_pwd  test -e 'drop table if exists marks,names;'";
  system "mysql -u root -p$mysql_pwd  test -e 'create table marks( roll int(5) not null,course int (3) not null,assignment int(2),project int(2),exam int(2) ,primary key(roll,course)); '";
  system "mysql -u root -p$mysql_pwd test -e 'create table names(roll int(5) not null primary key,name varchar(30)); '";
  system "echo 'Tables marks and names created'";
  print "init\n";
  $line=<STDIN>;
  for($i=0;$i<100;$i++)
  {
    #print $line;
    @col=split(",",$line);
    #print @col,"\n";
    @rolist[$i]=$col[0];
    for($j=0;$j<3;$j++)
    {
	    $assgmark=$col[4+3*$j];
	    $projmark=$col[5+3*$j];
	    $exammark=$col[6+3*$j];
	    system "mysql -u root -p$mysql_pwd  test -e 'insert into marks values($col[0],$col[1+$j],$assgmark,$projmark,$exammark);'";
	}
    $line=<STDIN>;
  }
  #$new=<STDIN>;
  #print $rolist[0],"\n";
  $infile = "names.txt"; # This is the file path
  open INFILE, $infile or die "Can't open $infile: $!"; 
  #print $infile;
  $j=0;
  while(<INFILE>)
  {
  chomp;
    @columns = split /\t/;
    #print @columns;
    $values=$rolist[$j].',"'.$columns[0].'"';
    #print $values,"\n";
    system "mysql -u root -p$mysql_pwd test -e 'insert into names values($values);'";
    #print "\n";
    $j=$j+1;
  }
  
    
    