#!/bin/bash
#
echo "Enter your mysql password followed by [ENTER]:"
read mysql_pwd

#Phase-1
octave <phase1.m >phase1.out

#Phase-2
chmod +x phase2.pl
./phase2.pl <phase1.out $mysql_pwd

#Phase-3
mysql -u root -p$mysql_pwd <phase3.sql >phase3.out

#Phase-4
chmod +x phase4.pl
./phase4.pl

#Phase-5
gnuplot <phase5.gnu

#Phase-6
cd Latex
pdflatex analysis.tex >temp.log
bibtex analysis.aux >temp1.log
pdflatex analysis.tex >temp.log
pdflatex analysis.tex >temp.log

#Phase-7
cd ..
chmod +x phase7.sh
./phase7.sh uncrack >temp3.log;
