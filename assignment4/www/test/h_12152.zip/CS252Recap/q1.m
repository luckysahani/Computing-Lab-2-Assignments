arr = [201,202,203,204,205,206,207,208,209];			#course numbers 
roll_list = 10000+(99999-10000)*rand(1,100);			#generate distinct roll numbers
for j=[1:100]											#loop 100 times
	
	course=randperm(9);									#generate distinct courses
	course_list=course([1:3]);							#select three courses
	fin(j,:)=[floor(roll_list(1,j)),arr(course_list(1)),arr(course_list(2)),arr(course_list(3)),floor(0+50*rand()),floor(0+50*rand()),floor(0+50*rand()),floor(0+50*rand()),floor(0+50*rand()),floor(0+50*rand()),floor(0+50*rand()),floor(0+50*rand()),floor(0+50*rand())];
	#genrate the required matrix
endfor
csvwrite("phase1.out",fin)


