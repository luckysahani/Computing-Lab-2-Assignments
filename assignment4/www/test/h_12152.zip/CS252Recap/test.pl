#!/usr/bin/perl -w
$thing=shift;
print $thing;
system "mysql -u root -p$thing  test -e 'drop table marks;'";