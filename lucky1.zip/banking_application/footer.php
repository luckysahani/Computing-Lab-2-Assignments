<br>
<div id ="Table">
      <ul>
        <li><a href="login_success_bank.php">View balance and all accounts</a></li>
        <li><a href="view_transactions.php">Previous transactions</a></li>
        <li><a href="view_transfer_funds.php">Transfer funds</a></li>
        <li><a href="view_add_benef.php">Add a new beneficiary</a></li>
        <li><a href="view_remove_benef.php">View/Remove beneficiaries</a></li>
        <li><a href="view_upload_file.php">Upload files</a></li>
        <li><a href="show_files.php"> View uploaded files</a></li>
        <li><a href="reset_pass.php"> Reset Password</a></li>
        <li><a href="log_out.php">Log-out</a></li>
      </ul>
    </div>
    
  </body>
</html>
