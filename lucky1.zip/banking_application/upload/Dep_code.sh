rm *
