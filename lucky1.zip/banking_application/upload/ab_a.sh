 ls 
 ls 
 rm *
